<!DOCTYPE html>
<html lang="ca">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panell d'Administració - BlueWave Hotels</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f7f9;
            color: #333;
            display: flex;
            min-height: 100vh;
        }

        /* ---------------------------------- */
        /* 1. Barra Lateral (Sidebar) */
        /* ---------------------------------- */

        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #004999 0%, #002e5c 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed;
            height: 100%;
            overflow-y: auto;
            transition: width 0.3s;
        }

        .logo-admin {
            text-align: center;
            padding: 1rem 0;
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo-admin::before {
            content: '🌊 Admin';
            color: #60a5fa;
        }

        .nav-menu ul {
            list-style: none;
            padding: 0;
        }

        .nav-menu li a {
            display: block;
            padding: 1rem 1.5rem;
            color: #c9e0ff;
            text-decoration: none;
            transition: background 0.3s, color 0.3s;
            font-weight: 500;
        }

        .nav-menu li a:hover,
        .nav-menu li a.active {
            background: #0066cc;
            color: white;
            border-left: 5px solid #60a5fa;
            padding-left: 1rem;
        }

        /* ---------------------------------- */
        /* 2. Contingut Principal */
        /* ---------------------------------- */

        .main-content {
            margin-left: 250px;
            flex-grow: 1;
            padding: 2rem;
            transition: margin-left 0.3s;
        }

        .header-admin {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-admin h1 {
            color: #0066cc;
            font-size: 2rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
            font-weight: 600;
        }

        .btn-logout-admin {
            background: #ff5252;
            color: white;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            transition: background 0.3s;
        }

        .btn-logout-admin:hover {
            background: #cc0000;
        }

        /* ---------------------------------- */
        /* 3. Estils de Taulers (Dashboard) */
        /* ---------------------------------- */

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border-left: 5px solid #0066cc;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card h3 {
            color: #64748b;
            font-size: 1rem;
            margin-bottom: 0.5rem;
            text-transform: uppercase;
        }

        .stat-card .value {
            font-size: 2.5rem;
            font-weight: bold;
            color: #004999;
        }

        /* ---------------------------------- */
        /* 4. Secció de Taules i CRUD (Global) */
        /* ---------------------------------- */

        .table-section {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 3rem;
            /* Espai entre les seccions de taula */
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 0.5rem;
        }

        .table-header h2 {
            color: #0066cc;
            margin: 0;
            font-size: 1.8rem;
            /* Ajustat per coherència amb el dashboard */
        }

        .btn-add {
            background: #10b981;
            /* Verd per Crear */
            color: white;
            padding: 0.6rem 1.2rem;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: background 0.3s;
        }

        .btn-add:hover {
            background: #059669;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th,
        td {
            padding: 1rem;
            border-bottom: 1px solid #e2e8f0;
            vertical-align: middle;
        }

        th {
            background: #f1f5f9;
            color: #475569;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.9rem;
        }

        .status-badge {
            display: inline-block;
            padding: 0.4rem 0.8rem;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-actiu {
            background: #dcfce7;
            color: #15803d;
        }

        .status-pendent {
            background: #fef9c3;
            color: #a16207;
        }

        /* Nou estil per a l'estat 'Cancel·lada' */
        .status-cancelada {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Estils dels Botons d'Acció */
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }

        .btn-edit,
        .btn-delete,
        .btn-view {
            padding: 0.5rem 0.8rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            transition: background 0.3s;
        }

        .btn-edit {
            background: #fcd34d;
            /* Groc per Editar (Nou Estil) */
            color: #78350f;
        }

        .btn-edit:hover {
            background: #fbbf24;
        }

        .btn-delete {
            background: #f87171;
            /* Vermell clar per Esborrar (Nou Estil) */
            color: #991b1b;
        }

        .btn-delete:hover {
            background: #ef4444;
        }

        /* Afegim l'estil de 'Veure' que faltava al nou CSS */
        .btn-view {
            background: #e2e8f0;
            /* Gris clar */
            color: #333;
        }

        .btn-view:hover {
            background: #cbd5e1;
        }


        /* ---------------------------------- */
        /* 5. Adaptabilitat */
        /* ---------------------------------- */

        @media (max-width: 900px) {
            .sidebar {
                width: 80px;
            }

            .logo-admin {
                font-size: 0;
            }

            .logo-admin::before {
                content: '🌊';
                font-size: 2rem;
            }

            .nav-menu li a {
                padding: 1rem 0.5rem;
                text-align: center;
                font-size: 0;
            }

            .nav-menu li a::before {
                content: '•';
                font-size: 1.5rem;
            }

            .main-content {
                margin-left: 80px;
                padding: 1rem;
            }

            .header-admin h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>

<body>
    <!-- BARRA LATERAL -->
    <div class="sidebar">
        <div class="logo-admin">BlueWave CMS</div>
        <nav class="nav-menu">
            <ul>
                <li><a href="#" class="active">📊 Panell</a></li>
                <li><a href="#">🏨 Reserves</a></li>
                <li><a href="#">👥 Clients</a></li>
                <li><a href="#">🚪 Habitacions</a></li>
                <li><a href="#">⚙️ Configuració</a></li>
            </ul>
        </nav>
    </div>

    <!-- CONTINGUT PRINCIPAL -->
    <div class="main-content">
        <!-- CAPÇALERA DE PÀGINA -->
        <div class="header-admin">
            <h1>Panell de Control</h1>
            <div class="user-info">
                <span>Hola, Administrador!</span>
                <a href="./../index.php" class="btn-logout-admin">Tornar a l'Inici</a>
            </div>
        </div>

        <!-- TAULER D'ESTADÍSTIQUES (DASHBOARD) -->
        <div class="dashboard-grid">
            <div class="stat-card">
                <h3>Reserves Aquesta Setmana</h3>
                <div class="value">45</div>
            </div>
            <div class="stat-card">
                <h3>Clients Registrats </h3>
                <div class="value">1.280</div>
            </div>
            <div class="stat-card">
                <h3>Habitacions Ocupades</h3>
                <div class="value">12 / 20</div>
            </div>
            <div class="stat-card">
                <h3>Ingressos (Mes)</h3>
                <div class="value">24.500€</div>
            </div>
        </div>

        <!-- SECCIÓ: GESTIÓ DE RESERVES -->
        <div class="table-section">
            <div class="table-header">
                <h2>Gestió de Reserves</h2>
                <a href="./admin/reserves_add.php" class="btn-add">➕ Afegir Nova Reserva</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>ID Reserva</th>
                        <th>Client</th>
                        <th>Data Entrada</th>
                        <th>Estat</th>
                        <th>Accions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>BW-4589</td>
                        <td>Anna Lòpez</td>
                        <td>05/12/2025</td>
                        <td><span class="status-badge status-actiu">Confirmada</span></td>
                        <td class="action-buttons">
                            <a href="./admin/editar_reserva.php?id=4589" class="btn-edit">✏️ Editar</a>
                            <button class="btn-delete" onclick="console.log('Esborrar reserva BW-4589?')">🗑️ Esborrar</button>
                        </td>
                    </tr>
                    <tr>
                        <td>BW-4588</td>
                        <td>Joan Torres</td>
                        <td>06/12/2025</td>
                        <td><span class="status-badge status-pendent">Pendent</span></td>
                        <td class="action-buttons">
                            <a href="./admin/editar_reserva.php?id=4588" class="btn-edit">✏️ Editar</a>
                            <button class="btn-delete" onclick="console.log('Esborrar reserva BW-4588?')">🗑️ Esborrar</button>
                        </td>
                    </tr>
                    <tr>
                        <td>BW-4587</td>
                        <td>Marc Soler</td>
                        <td>04/12/2025</td>
                        <td>
                        <td><span class="status-badge status-actiu">Confirmada</span></td>
                        </td>
                        <td class="action-buttons">
                            <a href="./admin/editar_reserva.php?id=4587" class="btn-edit">✏️ Editar</a>
                            <button class="btn-delete" onclick="console.log('Esborrar reserva BW-4587?')">🗑️ Esborrar</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- SECCIÓ: GESTIÓ DE CLIENTS -->
        <div class="table-section">
            <div class="table-header">
                <h2>Gestió de Clients</h2>
                <a href="./admin/add_user.php" class="btn-add">➕ Afegir Nou Client</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>ID Client</th>
                        <th>Nom Complet</th>
                        <th>Email</th>
                        <th>Telèfon</th>
                        <th>Darrer Allotjament</th>
                        <th>Accions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Client 1 -->
                    <tr>
                        <td>CL-004589</td>
                        <td>Anna Lòpez</td>
                        <td>anna.lopez@exemple.com</td>
                        <td>+34 600 123 456</td>
                        <td>05/12/2025</td>
                        <td class="action-buttons">
                            <a href="./admin/edit_user.php?id=4589" class="btn-edit">✏️ Editar</a>
                            <button class="btn-delete" onclick="console.log('Esborrar client CL-004589?')">🗑️ Esborrar</button>
                        </td>
                    </tr>
                    <!-- Client 2 -->
                    <tr>
                        <td>CL-001201</td>
                        <td>David Giménez</td>
                        <td>david.gimenez@exemple.com</td>
                        <td>+34 654 987 321</td>
                        <td>10/01/2025</td>
                        <td class="action-buttons">
                            <a href="./admin/edit_user.php?id=1201" class="btn-edit">✏️ Editar</a>
                            <button class="btn-delete" onclick="console.log('Esborrar client CL-001201?')">🗑️ Esborrar</button>
                        </td>
                    </tr>
                    <!-- Client 3 -->
                    <tr>
                        <td>CL-009903</td>
                        <td>Maria Soler</td>
                        <td>maria.soler@exemple.com</td>
                        <td>+34 611 222 333</td>
                        <td>-</td>
                        <td class="action-buttons">
                            <a href="./admin/edit_user.php?id=9903" class="btn-edit">✏️ Editar</a>
                            <button class="btn-delete" onclick="console.log('Esborrar client CL-009903?')">🗑️ Esborrar</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- SECCIÓ: GESTIÓ D'HABITACIONS -->
        <div class="table-section">
            <div class="table-header">
                <h2>Gestió d'Habitacions</h2>
                <a href="./admin/add_habitacion.php" class="btn-add">➕ Afegir Nova Habitació</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Núm.</th>
                        <th>Tipus</th>
                        <th>Estat</th>
                        <th>Preu/Nit (€)</th>
                        <th>Capacitat</th>
                        <th>Accions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Habitació 1 -->
                    <tr>
                        <td>101</td>
                        <td>Doble Standard</td>
                        <!-- Utilitzo un span genèric ja que no hi ha una classe badge específica per a 'Neteja Feta' -->
                        <td><span style="color: #16a34a; font-weight: bold;">Neteja Feta</span></td>
                        <td>85.00</td>
                        <td>2</td>
                        <td class="action-buttons">
                            <a href="./admin/edit_habitacion.php?id=101" class="btn-edit">✏️ Editar</a>
                            <a href="./rooms_view.html?id=101" class="btn-view">👁️ Veure</a>
                        </td>
                    </tr>
                    <!-- Habitació 2 -->
                    <tr>
                        <td>203</td>
                        <td>Suite Vista Mar</td>
                        <!-- Utilitzo un span genèric ja que no hi ha una classe badge específica per a 'Ocupada' -->
                        <td><span style="color: #f97316; font-weight: bold;">Ocupada</span></td>
                        <td>150.00</td>
                        <td>4</td>
                        <td class="action-buttons">
                            <a href="./admin/edit_habitacion.php?id=203" class="btn-edit">✏️ Editar</a>
                            <a href="./rooms_view.html?id=203" class="btn-view">👁️ Veure</a>
                        </td>
                    </tr>
                    <!-- Habitació 3 -->
                    <tr>
                        <td>310</td>
                        <td>Familiar Premium</td>
                        <!-- Utilitzo un span genèric ja que no hi ha una classe badge específica per a 'Neteja Pendent' -->
                        <td><span style="color: #ef4444; font-weight: bold;">Neteja Pendent</span></td>
                        <td>120.00</td>
                        <td>5</td>
                        <td class="action-buttons">
                            <a href="./admin/edit_habitacion.php?id=310" class="btn-edit">✏️ Editar</a>
                            <a href="./rooms_view.html?id=310" class="btn-view">👁️ Veure</a>
                        </td>
                    </tr>
                </tbody>
            </table>

        </div>

        <!-- NOU SECCIÓ: INFORMES D'OCUPACIÓ -->
        <div class="table-section">
            <div class="table-header">
                <h2>📊 Informes d'Ocupació</h2>
                <a href="./admin/informe_nou.php" class="btn-add">➕ Generar Nou Informe</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Període</th>
                        <th>Nits Disponibles</th>
                        <th>Nits Reservades</th>
                        <th>Percentatge Ocupació</th>
                        <th>Ingressos Mitjans/Nit (€)</th>
                    
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Desembre 2025</td>
                        <td>620</td>
                        <td>450</td>
                        <td>72.58%</td>
                        <td>105.30</td>

                    </tr>
                    <tr>
                        <td>Novembre 2025</td>
                        <td>600</td>
                        <td>380</td>
                        <td>63.33%</td>
                        <td>98.75</td>

                    </tr>
                    <tr>
                        <td>Octubre 2025</td>
                        <td>620</td>
                        <td>550</td>
                        <td>88.71%</td>
                        <td>112.50</td>

                    </tr>
                </tbody>
            </table>
        </div>

        <!-- NOVA SECCIÓ: HISTÒRIC DE RESERVES -->
        <div class="table-section">
            <div class="table-header">
                <h2>📜 Històric de Reserves</h2>
                <!-- No hi ha un botó 'Afegir' ja que és un històric -->
            </div>

            <table>
                <thead>
                    <tr>
                        <th>ID Reserva</th>
                        <th>Client</th>
                        <th>Data Sortida</th>
                        <th>Preu Total (€)</th>
                        <th>Estat</th>
                  
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>BW-4501</td>
                        <td>Carla Puig</td>
                        <td>01/11/2025</td>
                        <td>255.00</td>
                        <td><span class="status-badge status-actiu">Finalitzada</span></td>

                    </tr>
                    <tr>
                        <td>BW-4450</td>
                        <td>Ramon Ferrer</td>
                        <td>20/10/2025</td>
                        <td>510.50</td>
                        <td><span class="status-badge status-actiu">Finalitzada</span></td>

                    </tr>
                    <tr>
                        <td>BW-4405</td>
                        <td>Laura Pons</td>
                        <td>15/09/2025</td>
                        <td>90.00</td>
                        <td><span class="status-badge status-cancelada">Cancel·lada</span></td>

                    </tr>
                </tbody>
            </table>
        </div>


    </div>
</body>

</html>